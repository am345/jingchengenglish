# 模型来源

SyncNet 模型用于口型检测，源项目：https://github.com/joonson/syncnet_python 。对应模型代码和上游 MIT 许可随主仓库 vendor/syncnet 提供。

DeepFilterNet3 模型用于降噪，源项目：https://github.com/Rikorose/DeepFilterNet 。保留上游许可与使用条件。

R6/R2 参考音频与音色基准由项目所有者提供，并授权随本交接包公开。CosyVoice 微调权重不在包内。

本包保持既有模型文件内容；每项完整 SHA-256 见 manifest.json。
