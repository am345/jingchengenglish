# Windows 交接包

本包已获项目所有者同意，发布在景程口语公开仓库。包含当前服务器地址/模型目录、R6/R2 音色参考、精简音色基准、SyncNet 和 DeepFilterNet3 模型；不含 SSH 私钥、密码、Cookie 或账号登录状态。

先按仓库 README 在 Windows/WSL 安装，然后：

1. 将包里的 `config/local.toml` 和 `assets/` 复制到仓库对应目录。第一次配置可替换初始化模板；已有配置应合并，保留本机盘符、工具和代理设置。相对路径按仓库的 `config/` 目录解析。
2. 将 `ssh_config` 的两个 Host 条目合并到实际运行终端的 `~/.ssh/config`，不要覆盖已有条目。WSL 和原生 Windows 使用不同的用户目录。
3. 存储服务器私钥需另行配置到 `~/.ssh/jingcheng_storage`；配音服务器也需可用的 SSH 密钥或 agent。自动脚本不会输入密码。
4. 重新登录 Grok Build，并核对参数与隐私设置；就绪标志默认 false。
5. 人物参考/首尾帧、笔记 PDF、授权字体和具体课程时间线需另行准备。L40S 上的 CosyVoice 基模型与微调权重继续从服务器加载，未包含在本包中。
6. 运行 `jc doctor`、`jc server-check voice`、`jc server-check storage`，先渲染仓库的 3 秒课件示例。

`manifest.json` 记录每个文件的字节数和 SHA-256。服务器地址或环境变更时，只改自己的配置。发布包不意味着其他音频、人物、笔记或成片也获准公开。
